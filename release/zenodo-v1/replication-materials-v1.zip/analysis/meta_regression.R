#!/usr/bin/env Rscript
# ============================================================================
# meta_regression.R  — §6 meta-regression pipeline (v2: model-level pooling).
#
# Restructured from bucket-level (k=10) to model-level paired comparisons
# (k≥50) using per-task per-model data from fev-bench and Source B.
#
# Unit of analysis: one row per (FM_i, task, metric), paired against the
# within-cell average of available conventional baseline rows.
# Effect size: delta_ij = FM_metric - baseline_metric (absolute difference).
# Nesting: list(~1|dataset_norm/paper_id, ~1|model_name) to account for
# dataset-level correlation, within-task clustering, and non-independence
# of pairs from the same FM model.
#
# Inputs:
#   analysis/extraction_schema.csv  — Source A (literature) + fev-bench rows.
#   benchmark/results/local_fm_sweep.csv  — Source B rows (when available).
#
# Outputs (analysis/figures/):
#   table_6_1_model_level_deltas.csv
#   table_6_2_heterogeneity.csv
#   table_6_3_moderators.csv
#   figure_6_1_forest_*.pdf
#   figure_6_4_pareto_consumer_hw.pdf
#   sensitivity_*.txt
#
# Usage:
#   Rscript analysis/meta_regression.R
# ============================================================================

suppressPackageStartupMessages({
  library(metafor)
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readr)
  library(knitr)
})

SCHEMA_PATH    <- "analysis/extraction_schema.csv"
LOCAL_PATH     <- "benchmark/results/local_fm_sweep.csv"
BOOTSTRAP_PATH <- "analysis/figures/table_bootstrap_se.csv"
FIG_DIR        <- "analysis/figures"
dir.create(FIG_DIR, showWarnings = FALSE, recursive = TRUE)

# ---------------------------------------------------------------------------
# 1. Load + clean.
# ---------------------------------------------------------------------------

load_extraction <- function(path) {
  raw <- read_csv(
    path, comment = "#", show_col_types = FALSE,
    col_types = cols(
      paper_id = col_character(),
      year = col_integer(),
      n_series = col_character(),
      series_length_median = col_character(),
      horizon = col_character(),
      metric_value = col_character(),
      .default = col_character()
    )
  )
  raw$source <- "LIT"
  raw
}

# Retail datasets we meta-analyze.
RETAIL_DATASETS <- c(
  "M5", "Favorita", "Rohlik v2", "VN1 Forecasting (Rohlik)",
  "fev-bench", "retail (unnamed)", "Rossmann", "Walmart",
  "SE Europe retail (proprietary)", "M5 + 3 external",
  "Restaurant", "Hierarchical Sales", "Hermes", "Car Parts"
)

# Dataset-level n_series for variance proxy.
DATASET_N_SERIES <- c(
  "M5"       = 30490,
  "Favorita" = 30000,
  "Rohlik"   = 5390,
  "Walmart"  = 2936,
  "Car Parts" = 2674,
  "Rossmann" = 1115,
  "Restaurant" = 813,
  "Hierarchical Sales" = 118,
  "Hermes"   = 10000,
  "fev-bench" = 5000
)

# FM model scale (log10 params) for moderator analysis.
FM_LOG_PARAMS <- c(
  "Chronos-2"           = log10(120e6),    # ~8.08
  "TiRex"               = log10(35e6),     # ~7.54
  "TimesFM-2.5"         = log10(200e6),    # ~8.30
  "Moirai-2.0-Small"    = log10(11e6),     # ~7.04
  "Chronos-Bolt-Base"   = log10(46e6),     # ~7.66
  "Chronos-Bolt-Tiny"   = log10(9e6),      # ~6.95
  "TabPFN-TS"           = log10(12e6),     # ~7.08
  "Toto-1.0"            = log10(100e6),    # ~8.00
  "chronos_bolt_tiny"   = log10(9e6),
  "tirex"               = log10(35e6),
  "chronos2"            = log10(120e6),
  "moirai2"             = log10(11e6),
  "timesfm25"           = log10(200e6)
)

normalize_dataset <- function(d) {
  dplyr::case_when(
    # fev-bench per-task datasets
    grepl("fev-bench/m5_", d, ignore.case = TRUE) ~ "M5",
    grepl("fev-bench/favorita_", d, ignore.case = TRUE) ~ "Favorita",
    grepl("fev-bench/rohlik_", d, ignore.case = TRUE) ~ "Rohlik",
    grepl("fev-bench/rossmann", d, ignore.case = TRUE) ~ "Rossmann",
    grepl("fev-bench/walmart", d, ignore.case = TRUE) ~ "Walmart",
    grepl("fev-bench/restaurant", d, ignore.case = TRUE) ~ "Restaurant",
    grepl("fev-bench/hierarchical", d, ignore.case = TRUE) ~ "Hierarchical Sales",
    grepl("fev-bench/hermes", d, ignore.case = TRUE) ~ "Hermes",
    # GIFT-Eval Sales domain datasets
    grepl("GIFT-Eval.*Car Parts", d, ignore.case = TRUE) ~ "Car Parts",
    grepl("GIFT-Eval.*Hierarchical", d, ignore.case = TRUE) ~ "Hierarchical Sales",
    grepl("GIFT-Eval.*Restaurant", d, ignore.case = TRUE) ~ "Restaurant",
    # Legacy aggregate fev-bench rows
    grepl("^fev-bench$", d, ignore.case = TRUE) ~ "fev-bench",
    # Standard datasets
    grepl("^M5", d, ignore.case = TRUE) ~ "M5",
    grepl("Favorita", d, ignore.case = TRUE) ~ "Favorita",
    grepl("Rohlik|VN1", d, ignore.case = TRUE) ~ "Rohlik",
    grepl("Walmart", d, ignore.case = TRUE) ~ "Walmart",
    grepl("Rossmann", d, ignore.case = TRUE) ~ "Rossmann",
    TRUE ~ NA_character_
  )
}

normalize_family <- function(f) {
  dplyr::case_when(
    f %in% c("foundation") ~ "FM",
    f %in% c("ml_tree", "ml_gbm", "gbdt", "ml",
             "ml_ensemble", "ml_hybrid") ~ "ML_TREE",
    f %in% c("statistical", "stat", "ets") ~ "STATS",
    f %in% c("nn", "deep", "transformer", "rnn",
             "deep_learning", "ensemble_dl") ~ "NN",
    TRUE ~ NA_character_
  )
}

parse_metric <- function(x) suppressWarnings(as.numeric(x))

bucket_horizon <- function(h) {
  n <- suppressWarnings(as.integer(h))
  dplyr::case_when(
    is.na(n) ~ "mixed",
    n <= 7 ~ "short",
    n <= 14 ~ "medium",
    TRUE ~ "long"
  )
}

prepare_rows <- function(raw) {
  raw %>%
    mutate(
      dataset_norm = normalize_dataset(dataset),
      family = normalize_family(model_family),
      metric_num = parse_metric(metric_value),
      horizon_bucket = bucket_horizon(horizon),
      has_covariates = tolower(has_covariates) %in% c("yes", "true", "1"),
      zero_shot = tolower(zero_shot) %in% c("yes", "true", "1"),
      fine_tuned = tolower(fine_tuned) %in% c("yes", "true", "1"),
      n_series_num = {
        parsed <- suppressWarnings(as.numeric(gsub("[^0-9.]", "", n_series)))
        ifelse(is.na(parsed),
               DATASET_N_SERIES[normalize_dataset(dataset)],
               parsed)
      },
      # Model scale moderator (log10 params, FM only).
      model_scale = FM_LOG_PARAMS[model_name]
    ) %>%
    filter(
      !is.na(dataset_norm),
      !is.na(family),
      !is.na(metric_num)
    )
}

# ---------------------------------------------------------------------------
# 2. Model-level paired deltas (NEW — primary for k≥50).
#
# For each (paper_id × metric) group that contains both FM and conventional
# baseline rows, compute one delta per FM model:
# delta_i = FM_i_metric - mean(available baseline metrics).
# This is the new unit of analysis.
# ---------------------------------------------------------------------------

load_bootstrap_se <- function(path = BOOTSTRAP_PATH) {
  if (!file.exists(path)) {
    message("Bootstrap SE file not found: ", path)
    return(NULL)
  }
  bse <- read_csv(path, show_col_types = FALSE) %>%
    mutate(
      dataset_norm = case_when(
        dataset == "m5"       ~ "M5",
        dataset == "favorita" ~ "Favorita",
        dataset == "rohlik"   ~ "Rohlik",
        TRUE ~ NA_character_
      ),
      horizon_bucket = case_when(
        horizon <= 7  ~ "short",
        horizon <= 14 ~ "medium",
        TRUE          ~ "long"
      )
    ) %>%
    select(dataset_norm, horizon_bucket, model_name = model,
           bootstrap_se) %>%
    filter(!is.na(dataset_norm))
  bse
}

compute_model_level_delta <- function(rows, bootstrap_se_df = NULL,
                                      baseline_strategy = c("average", "best")) {
  baseline_strategy <- match.arg(baseline_strategy)
  # Within each paper_id (= task for fev-bench/GIFT-Eval, = dataset×horizon
  # for Source B), pair each FM row with conventional baselines. The primary
  # strategy uses the within-cell average of available conventional baselines.
  # The "best" sensitivity uses the lowest-error conventional baseline in the
  # same cell. This allows GIFT-Eval (STATS baselines), fev-bench
  # (ML_TREE/STATS baselines), and Source B (LightGBM + Seasonal Naive) to all
  # contribute paired comparisons.
  baseline_families <- c("ML_TREE", "STATS")

  by_group <- rows %>%
    filter(family %in% c("FM", baseline_families)) %>%
    group_by(paper_id, dataset_norm, horizon_bucket, metric_name) %>%
    filter(any(family == "FM"), any(family %in% baseline_families)) %>%
    ungroup()

  baseline_rows <- by_group %>%
    filter(family %in% baseline_families) %>%
    group_by(paper_id, dataset_norm, horizon_bucket, metric_name) %>%
    mutate(n_baseline_available = n()) %>%
    ungroup()

  if (baseline_strategy == "average") {
    baselines <- baseline_rows %>%
      group_by(paper_id, dataset_norm, horizon_bucket, metric_name) %>%
      summarise(
        baseline_metric = mean(metric_num, na.rm = TRUE),
        baseline_family = first(family),
        n_baseline = n(),
        baseline_n_series = mean(n_series_num, na.rm = TRUE),
        .groups = "drop"
      )
  } else {
    baselines <- baseline_rows %>%
      group_by(paper_id, dataset_norm, horizon_bucket, metric_name) %>%
      slice_min(metric_num, n = 1, with_ties = FALSE) %>%
      ungroup() %>%
      transmute(
        paper_id, dataset_norm, horizon_bucket, metric_name,
        baseline_metric = metric_num,
        baseline_family = family,
        n_baseline = n_baseline_available,
        baseline_n_series = n_series_num
      )
  }

  # FM rows joined with their within-group baseline.
  fm_rows <- by_group %>%
    filter(family == "FM") %>%
    inner_join(baselines, by = c("paper_id", "dataset_norm",
                                  "horizon_bucket", "metric_name"))

  # Compute delta and variance proxy.
  result <- fm_rows %>%
    mutate(
      delta = metric_num - baseline_metric,
      # Relative delta: (FM - baseline) / baseline. Used for moderator plots.
      delta_rel = ifelse(baseline_metric > 0,
                         (metric_num - baseline_metric) / baseline_metric,
                         NA_real_),
      # Default variance proxy: 1/n_series for each side, summed.
      vi = (1 / pmax(n_series_num, 1)) + (1 / pmax(baseline_n_series, 1)),
      # Unique pair ID for clustering.
      pair_id = paste(paper_id, model_name, metric_name, sep = "__")
    ) %>%
    filter(is.finite(delta))

  # For Source B WAPE pairs: replace vi with bootstrap SE² if available.
  if (!is.null(bootstrap_se_df) && nrow(bootstrap_se_df) > 0) {
    result <- result %>%
      left_join(bootstrap_se_df,
                by = c("dataset_norm", "horizon_bucket",
                       "model_name" = "model_name"),
                suffix = c("", ".bse")) %>%
      mutate(
        vi = ifelse(source == "LOCAL" & metric_name == "WAPE" &
                      !is.na(bootstrap_se),
                    bootstrap_se^2,
                    vi)
      ) %>%
      select(-bootstrap_se)
  }

  result %>%
    select(pair_id, paper_id, dataset_norm, horizon_bucket, metric_name,
           model_name, model_scale, has_covariates, zero_shot,
           metric_num, baseline_metric, baseline_family,
           delta, delta_rel, vi, source,
           n_series_num, baseline_n_series)
}

# ---------------------------------------------------------------------------
# 3. Legacy bucket-level deltas (kept for backward compatibility / sensitivity).
# ---------------------------------------------------------------------------

compute_crosspaper_delta <- function(rows) {
  rows %>%
    filter(family %in% c("FM", "ML_TREE")) %>%
    group_by(dataset_norm, horizon_bucket, metric_name) %>%
    filter(any(family == "FM"), any(family == "ML_TREE")) %>%
    summarise(
      fm       = mean(metric_num[family == "FM"], na.rm = TRUE),
      ml_tree  = mean(metric_num[family == "ML_TREE"], na.rm = TRUE),
      n_fm     = sum(family == "FM"),
      n_mltree = sum(family == "ML_TREE"),
      n_series_hm = 1 / mean(1 / n_series_num, na.rm = TRUE),
      .groups  = "drop"
    ) %>%
    mutate(
      delta = fm - ml_tree,
      vi    = (1 / n_fm + 1 / n_mltree) * (1 / n_series_hm)
    ) %>%
    filter(is.finite(delta))
}

# ---------------------------------------------------------------------------
# 4. Meta-regression fits.
# ---------------------------------------------------------------------------

fit_model_level <- function(delta_df) {
  # Primary model: model-level deltas with three-level random effects.
  # (1) ~1|dataset_norm/paper_id: dataset-level and within-task clustering.
  # (2) ~1|model_name: non-independence of pairs from the same FM.
  # k = nrow(delta_df), typically ≥50 with fev-bench expansion.
  rma.mv(
    yi = delta, V = vi,
    random = list(~ 1 | dataset_norm / paper_id, ~ 1 | model_name),
    data = delta_df,
    test = "t",
    method = "REML"
  )
}

fit_model_level_mods <- function(delta_df, moderator) {
  rma.mv(
    yi = delta, V = vi,
    mods = as.formula(paste("~", moderator)),
    random = list(~ 1 | dataset_norm / paper_id, ~ 1 | model_name),
    data = delta_df,
    test = "t",
    method = "REML"
  )
}

fit_model_level_equal_weight <- function(delta_df) {
  # Robustness check for the sampling-variance proxy.  This keeps the same
  # random-effects structure but gives every paired comparison identical V.
  rma.mv(
    yi = delta, V = rep(1, nrow(delta_df)),
    random = list(~ 1 | dataset_norm / paper_id, ~ 1 | model_name),
    data = delta_df,
    test = "t",
    method = "REML"
  )
}

# Legacy fits (bucket-level).
fit_meta_crosspaper <- function(delta_df) {
  rma.mv(
    yi = delta, V = vi,
    random = ~ 1 | dataset_norm,
    data = delta_df,
    test = "t",
    method = "REML"
  )
}

# ---------------------------------------------------------------------------
# 5. Forest plots.
# ---------------------------------------------------------------------------

save_forest <- function(delta_df, dataset, out_path) {
  sub <- delta_df %>% filter(dataset_norm == dataset)
  if (nrow(sub) < 2) {
    message(sprintf("Skipping forest for %s (n=%d rows)", dataset, nrow(sub)))
    return(invisible(NULL))
  }
  sub_fit <- tryCatch(
    rma.mv(
      yi = delta, V = vi,
      random = ~ 1 | paper_id,
      data = sub, test = "t", method = "REML"
    ),
    error = function(e) { message("Per-dataset fit failed for ", dataset, ": ", e$message); NULL }
  )
  if (is.null(sub_fit)) return(invisible(NULL))

  slab_labels <- paste0(sub$model_name, " (", sub$metric_name, ")")
  pdf(out_path, width = 8, height = max(4, 0.35 * nrow(sub) + 2))
  forest(sub_fit, slab = slab_labels,
         xlab = "FM - baseline delta", main = dataset)
  dev.off()
  message("Wrote ", out_path)
}

# ---------------------------------------------------------------------------
# 6. Pareto frontier.
# ---------------------------------------------------------------------------

pareto_plot <- function(rows, cost_axis, out_path) {
  if (!("cost_usd" %in% colnames(rows))) {
    message(sprintf("Skipping %s Pareto — cost_usd column missing", cost_axis))
    return(invisible(NULL))
  }
  have <- rows %>%
    filter(!is.na(metric_num), !is.na(cost_usd), cost_usd > 0)
  if (nrow(have) < 2) {
    message(sprintf("Skipping %s Pareto — need Source B cost rows", cost_axis))
    return(invisible(NULL))
  }
  # Use shape to distinguish hardware cost basis (MacBook vs Azure).
  has_hw <- "hardware" %in% colnames(have) && n_distinct(have$hardware) > 1
  if (has_hw) {
    p <- ggplot(have, aes(cost_usd, metric_num, colour = family, shape = hardware)) +
      geom_point(size = 2.5) +
      scale_x_log10() +
      labs(x = "Cost (USD, log scale)",
           y = "WAPE",
           colour = "Model family",
           shape = "Hardware")
  } else {
    p <- ggplot(have, aes(cost_usd, metric_num, colour = family)) +
      geom_point(size = 2.5) +
      scale_x_log10() +
      labs(x = "Cost (USD, log scale)",
           y = "WAPE",
           colour = "Model family")
  }
  p <- p + theme_minimal(base_size = 11)
  ggsave(out_path, p, width = 7, height = 5)
  message("Wrote ", out_path)
}

# ---------------------------------------------------------------------------
# 7. Sensitivity analyses.
# ---------------------------------------------------------------------------

run_sensitivity <- function(delta_df, label, out_prefix) {
  if (nrow(delta_df) < 3) {
    message(sprintf("Sensitivity '%s': k=%d, skipped.", label, nrow(delta_df)))
    return(invisible(NULL))
  }
  message(sprintf("\n--- Sensitivity: %s (k=%d) ---", label, nrow(delta_df)))
  fit <- tryCatch(
    fit_model_level(delta_df),
    error = function(e) { message("  fit failed: ", e$message); NULL }
  )
  if (!is.null(fit)) {
    print(fit)
    writeLines(capture.output(print(fit)),
               file.path(FIG_DIR, paste0(out_prefix, ".txt")))
  }
  invisible(fit)
}

run_equal_weight_sensitivity <- function(delta_df, label, out_prefix) {
  if (nrow(delta_df) < 3) {
    message(sprintf("Sensitivity '%s': k=%d, skipped.", label, nrow(delta_df)))
    return(invisible(NULL))
  }
  message(sprintf("\n--- Sensitivity: %s (k=%d) ---", label, nrow(delta_df)))
  fit <- tryCatch(
    fit_model_level_equal_weight(delta_df),
    error = function(e) { message("  fit failed: ", e$message); NULL }
  )
  if (!is.null(fit)) {
    print(fit)
    writeLines(capture.output(print(fit)),
               file.path(FIG_DIR, paste0(out_prefix, ".txt")))
  }
  invisible(fit)
}

# ---------------------------------------------------------------------------
# 8. Main.
# ---------------------------------------------------------------------------

main <- function() {
  message("Loading Source A from ", SCHEMA_PATH)
  raw <- load_extraction(SCHEMA_PATH)

  if (file.exists(LOCAL_PATH)) {
    message("Appending Source B from ", LOCAL_PATH)
    loc <- read_csv(LOCAL_PATH, show_col_types = FALSE)
    loc$source <- "LOCAL"
    cast_cols <- intersect(
      c("n_series", "series_length_median", "horizon", "metric_value",
        "runtime_reported", "gpu_hours"),
      colnames(loc)
    )
    for (col in cast_cols) loc[[col]] <- as.character(loc[[col]])
    if ("year" %in% colnames(loc)) loc$year <- as.integer(loc$year)
    raw <- bind_rows(raw, loc)
  } else {
    message("Source B file not found at ", LOCAL_PATH,
            " — running on Source A only.")
  }

  rows <- prepare_rows(raw)
  message(sprintf("Prepared %d analysis rows across %d papers, %d datasets.",
                  nrow(rows), n_distinct(rows$paper_id),
                  n_distinct(rows$dataset_norm)))

  # ---- Load bootstrap SEs for Source B (if available) ----
  bse_df <- load_bootstrap_se()

  # ---- Model-level deltas (PRIMARY, k≥50) ----
  model_delta <- compute_model_level_delta(rows, bootstrap_se_df = bse_df,
                                           baseline_strategy = "average")
  message(sprintf("\nModel-level Δ: %d pairs across %d datasets, %d unique FMs.",
                  nrow(model_delta), n_distinct(model_delta$dataset_norm),
                  n_distinct(model_delta$model_name)))

  # Write delta table for paper.
  write_csv(model_delta,
            file.path(FIG_DIR, "table_6_1_model_level_deltas.csv"))

  if (nrow(model_delta) >= 5) {
    message("\n--- Primary model-level fit (all metrics, all datasets) ---")
    res_primary <- fit_model_level(model_delta)
    print(res_primary)
    writeLines(capture.output(print(res_primary)),
               file.path(FIG_DIR, "table_6_1_primary_intercept.txt"))

    # Heterogeneity diagnostics.
    het_df <- data.frame(
      k = res_primary$k,
      estimate = res_primary$beta[1],
      se = res_primary$se,
      ci_lb = res_primary$ci.lb,
      ci_ub = res_primary$ci.ub,
      pval = res_primary$pval,
      QE = res_primary$QE,
      QEp = res_primary$QEp,
      sigma2_dataset = res_primary$sigma2[1],
      sigma2_paper = res_primary$sigma2[2]
    )
    write_csv(het_df, file.path(FIG_DIR, "table_6_2_heterogeneity.csv"))

    # Moderator analyses.
    mod_results <- list()
    moderators <- c("dataset_norm", "horizon_bucket", "metric_name")
    # model_scale only for FM rows that have it.
    if (any(!is.na(model_delta$model_scale))) {
      moderators <- c(moderators, "model_scale")
    }
    # baseline_family moderator (ML_TREE vs STATS) — if both types present.
    if ("baseline_family" %in% colnames(model_delta) &&
        n_distinct(model_delta$baseline_family) > 1) {
      moderators <- c(moderators, "baseline_family")
    }
    for (mod in moderators) {
      mod_results[[mod]] <- tryCatch(
        fit_model_level_mods(model_delta, mod),
        error = function(e) {
          message("Moderator ", mod, " failed: ", e$message)
          NULL
        }
      )
      if (!is.null(mod_results[[mod]])) {
        writeLines(capture.output(print(mod_results[[mod]])),
                   file.path(FIG_DIR, sprintf("moderator_%s.txt", mod)))
      }
    }

    # Forest plots per dataset.
    for (ds in unique(model_delta$dataset_norm)) {
      save_forest(model_delta, ds,
                  file.path(FIG_DIR, sprintf("figure_6_forest_%s.pdf",
                                              gsub(" ", "_", tolower(ds)))))
    }
  } else {
    message("Fewer than 5 model-level Δ rows — primary regression skipped.")
  }

  # ---- Sensitivity analyses ----

  # Best conventional baseline per cell (reviewer-stringent comparator).
  model_delta_best <- compute_model_level_delta(rows, bootstrap_se_df = bse_df,
                                                baseline_strategy = "best")
  write_csv(model_delta_best,
            file.path(FIG_DIR, "table_6_1_model_level_deltas_best_baseline.csv"))
  run_sensitivity(
    model_delta_best,
    "Best conventional baseline per cell", "sensitivity_best_baseline"
  )

  # Excl-M5 (metric artefact sensitivity).
  run_sensitivity(
    model_delta %>% filter(dataset_norm != "M5"),
    "Excl M5", "sensitivity_excl_m5"
  )

  # WAPE-only (metric consistency).
  run_sensitivity(
    model_delta %>% filter(metric_name == "WAPE"),
    "WAPE only", "sensitivity_wape_only"
  )

  # SQL-only (fev-bench primary metric).
  run_sensitivity(
    model_delta %>% filter(metric_name == "SQL"),
    "SQL only", "sensitivity_sql_only"
  )

  # Source B only (own experiments).
  run_sensitivity(
    model_delta %>% filter(grepl("^LOCAL", source)),
    "Source B only", "sensitivity_source_b_only"
  )

  # Source A only (literature).
  run_sensitivity(
    model_delta %>% filter(source == "LIT"),
    "Source A only", "sensitivity_source_a_only"
  )

  # Leave-one-suite-out checks for benchmark-suite dominance.
  run_sensitivity(
    model_delta %>% filter(!grepl("^B02_fev", paper_id)),
    "Leave fev-bench out", "sensitivity_without_fev_bench"
  )
  run_sensitivity(
    model_delta %>% filter(!grepl("^B03_gift", paper_id)),
    "Leave GIFT-Eval out", "sensitivity_without_gift_eval"
  )

  # Equal-weight robustness check for the vi proxy.
  run_equal_weight_sensitivity(
    model_delta,
    "Equal-weight V", "sensitivity_equal_weight"
  )

  # ---- Legacy bucket-level (for comparison with original k=10) ----
  delta_cross <- compute_crosspaper_delta(rows)
  if (nrow(delta_cross) >= 3) {
    message("\n--- Legacy cross-paper bucket Δ (k=", nrow(delta_cross), ") ---")
    res_cross <- fit_meta_crosspaper(delta_cross)
    print(res_cross)
    writeLines(capture.output(print(res_cross)),
               file.path(FIG_DIR, "legacy_crosspaper_intercept.txt"))
    write_csv(delta_cross,
              file.path(FIG_DIR, "legacy_crosspaper_cells.csv"))
  }

  # ---- Funnel plot + Egger's test (PRISMA Item 14: publication bias) ----
  sql_delta <- model_delta %>% filter(metric_name == "SQL")
  if (nrow(sql_delta) >= 10) {
    sql_fit <- tryCatch(fit_model_level(sql_delta), error = function(e) NULL)
    if (!is.null(sql_fit)) {
      # Funnel plot (SQL-only)
      pdf(file.path(FIG_DIR, "figure_funnel_sql.pdf"), width = 7, height = 5)
      funnel(sql_fit, main = "Funnel plot: SQL-only (k = 138)",
             xlab = expression(hat(Delta)), ylab = "SE")
      dev.off()
      message("Wrote ", file.path(FIG_DIR, "figure_funnel_sql.pdf"))

      # Regression-based test for funnel asymmetry (Egger-type).
      # Add sqrt(vi) as a moderator in the rma.mv model.
      sql_delta_egger <- sql_delta %>% mutate(sei = sqrt(vi))
      egger_fit <- tryCatch(
        rma.mv(yi = delta, V = vi,
               mods = ~ sei,
               random = list(~ 1 | dataset_norm / paper_id, ~ 1 | model_name),
               data = sql_delta_egger,
               test = "t", method = "REML"),
        error = function(e) {
          message("Egger-type test failed: ", e$message)
          NULL
        }
      )
      if (!is.null(egger_fit)) {
        egger_out <- capture.output(print(egger_fit))
        writeLines(egger_out, file.path(FIG_DIR, "egger_sql.txt"))
        # The coefficient on sei tests for funnel asymmetry.
        sei_row <- which(rownames(egger_fit$beta) == "sei")
        message(sprintf("Egger-type test (SQL): sei coef = %.3f, p = %.4f",
                        egger_fit$beta[sei_row], egger_fit$pval[sei_row]))
      }
    }
  }

  # ---- Pareto plots ----
  pareto_plot(rows, "consumer_hw",
              file.path(FIG_DIR, "figure_6_4_pareto_consumer_hw.pdf"))
  pareto_plot(rows, "cloud_gpu",
              file.path(FIG_DIR, "figure_6_5_pareto_cloud_gpu.pdf"))

  # ---- Summary ----
  message("\n=== Summary ===")
  message(sprintf("Total analysis rows: %d", nrow(rows)))
  message(sprintf("Model-level Δ pairs (k): %d", nrow(model_delta)))
  message(sprintf("Datasets: %s", paste(unique(model_delta$dataset_norm), collapse=", ")))
  message(sprintf("FM models: %s", paste(unique(model_delta$model_name), collapse=", ")))
  message(sprintf("Metrics: %s", paste(unique(model_delta$metric_name), collapse=", ")))
  message(sprintf("Outputs in %s", FIG_DIR))
}

main()
